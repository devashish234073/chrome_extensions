Update 2.0.0 to youtube_view_noter.

1. When user visits a video, background script takes the count automatically, no need to manually click on the extension to take count.
2. Duplicate counts are skipped. [Clicking on the extension still takes the count if same count not noted previously]
3. Counts lesser than last noted count are ignored, so that the table always note latest data and not from some previously opened tab.
4. "Clear All button" in the extension to clear all the [OLDER] data that the extension had collected.

![image](https://user-images.githubusercontent.com/20777854/152982157-b42f893e-c536-4547-96ba-15e19c57e4f7.png)
